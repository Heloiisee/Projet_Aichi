package model;

public class ArticleDAO {
}
