package viewsAccueil;

import controller.Clientcontroller;
import controller.CommandeController;
import controller.FArticlesController;
import view.ClientView;
import view.CommandeView;


import java.awt.event.*;

public class FAccueilController {
    private final FAccueilView view;

    public FAccueilController(FAccueilView view) {
        this.view = view;
        initController();

    }

    public void initController() {
        view.addQuitterListener(new QuitterListener());
        view.addArticlesListener(new ArticlesListener());
        view.addClientsListener(new ClientsListener());
        view.addCommandesListener(new CommandesListener());
    }

    static class QuitterListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    class ArticlesListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            view.setInfoText("Affichage des Articles");
            afficherArticles();
        }
    }


    class ClientsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            view.setInfoText("Affichage des Clients");
            afficherClients();
        }
    }

    class CommandesListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            view.setInfoText("Affichage des Commandes");
            afficherCommandes();
        }
    }

    protected void afficherArticles() {
        FArticlesView laFenetre = FArticlesView.getInstance();
        FArticlesController controller = new FArticlesController(laFenetre);
        controller.initController();
        laFenetre.setVisible(true);

    }

    protected void afficherClients() {
        ClientView laFenetre = ClientView.getInstance();
        Clientcontroller controller = new Clientcontroller(laFenetre);
        controller.initController();
        laFenetre.setVisible(true);
    }

    protected void afficherCommandes() {

        CommandeView laFenetre = CommandeView.getInstance();
        CommandeController controller = new CommandeController(laFenetre);
        controller.initController();
        // Affichez la fenêtre
        laFenetre.setVisible(true);
    }

}