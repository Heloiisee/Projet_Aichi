package controller;

import model.Commande;
import model.CommandeDAO;
import view.CommandeView;

import javax.swing.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Classe CommandeController
 */
public class CommandeController {
    private final CommandeView view;
    private List<Commande> commandes;
    private CommandeDAO commandeDAO;

    /**
     * Constructeur par défaut
     *
     * @param view
     */
    public CommandeController(CommandeView view) {
        this.view = view;
        this.commandeDAO = new CommandeDAO();
        this.commandes = new ArrayList<>(); // Initialisation de la liste
        initController();
    }

    /**
     * Initialisation du contrôleur
     */
    public void initController() {
        // Ajout des ActionListeners qu'une seule fois
        view.setValiderActionListener(e -> ajouterCommande());
        view.setEffacerActionListener(e -> effacerSaisie());
        view.setAfficherActionListener(e -> afficherCommandes());
        view.setRetourActionListener(e -> retourAccueil());
        view.setSupprimerActionListener(e -> supprimerCommande());
        view.setModifierActionListener(e -> modifierCommande());
        view.setDetailsActionListener(e -> afficherDetailCommande());
    }

    private void ajouterCommande() {
        try {
            Commande commande = extraireCommandeDeVue();
            if (commande == null) {
                showMessage("Veuillez remplir tous les champs.");
                return;
            }

            commandeDAO.ajouterCommande(commande);
            commandes.add(commande);
            List<Commande> updatedCommandes = commandeDAO.getAllCommandes();
            view.afficherCommandesDansTable(updatedCommandes);

            showMessage("Commande ajoutée avec succès !");
            effacerSaisie();
        } catch (Exception e) {
            handleException(e, "Erreur lors de l'ajout de la commande : ");
        }
    }

    private void effacerSaisie() {
        view.clearFields();
    }

    private void afficherCommandes() {
        try {
            commandes = commandeDAO.getAllCommandes();
            view.afficherCommandesDansTable(commandes);
        } catch (Exception e) {
            handleException(e, "Erreur lors de l'affichage des commandes : ");
        }
    }

    private void retourAccueil() {
        view.setVisible(false);
    }

    private void supprimerCommande() {
//
        try {
            int selectedRow = view.getTableCommande().getSelectedRow();
            if (selectedRow == -1) {
                showMessage("Veuillez sélectionner une commande à supprimer.");
                return;
            }
            int nCommande = (int) view.getTableCommande().getValueAt(selectedRow, 0);
            commandes.removeIf(c -> c.getNCommande() == nCommande);
            commandeDAO.supprimerCommande(nCommande);
            view.afficherCommandesDansTable(commandes);
            showMessage("Commande supprimée avec succès.");
        } catch (Exception e) {
            handleException(e, "Erreur lors de la suppression de la commande : ");
        }
    }

    private void modifierCommande() {
        try {
            int selectedRow = view.getTableCommande().getSelectedRow();
            if (selectedRow == -1) {
                showMessage("Veuillez sélectionner une commande à modifier.");
                return;
            }
            int nCommande = (int) view.getTableCommande().getValueAt(selectedRow, 0);
            Commande commande = extraireCommandeDeVue();
            if (commande == null) {
                showMessage("Veuillez remplir tous les champs.");
                return;
            }
            commande.setNCommande(nCommande);

            commandeDAO.modifierCommande(commande);
            commandes.removeIf(c -> c.getNCommande() == nCommande);
            commandes.add(commande);
            view.afficherCommandesDansTable(commandes);

            showMessage("Commande modifiée avec succès.");
            effacerSaisie();
        } catch (Exception e) {
            handleException(e, "Erreur lors de la modification de la commande : ");
        }
    }

    private void afficherDetailCommande() {
        try {
            int selectedRow = view.getTableCommande().getSelectedRow();
            if (selectedRow == -1) {
                showMessage("Veuillez sélectionner une commande pour afficher les détails.");
                return;
            }
            int nCommande = (int) view.getTableCommande().getValueAt(selectedRow, 0);
            Commande commande = commandeDAO.getCommandeById(nCommande);
            showMessage("Détails de la commande : \n" +
                    "ID Client : " + commande.getIdClient() + "\n" +
                    "Date Commande : " + commande.getDate_Commande() + "\n" +
                    "Statut : " + commande.getStatut());
        } catch (Exception e) {
            handleException(e, "Erreur lors de l'affichage des détails de la commande : ");
        }
    }

    private Commande extraireCommandeDeVue() {
        try {
            int id_client = Integer.parseInt(view.getTxtIdClient());
            String date = view.getTxtDateCommande();
            String statut = view.getTxtStatut();

            if (date.isEmpty() || statut.isEmpty()) {
                return null;
            }

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date dateCommande = dateFormat.parse(date);
            return new Commande(id_client, dateCommande, statut);
        } catch (NumberFormatException | ParseException e) {
            showMessage("Format de date invalide ou valeurs non valides. Utilisez yyyy-MM-dd.");
            return null;
        }
    }

    private void showMessage(String message) {
        JOptionPane.showMessageDialog(view, message);
    }

    private void handleException(Exception e, String message) {
        showMessage(message + e.getMessage());
    }
}
