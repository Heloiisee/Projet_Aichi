package model;
import model.ArticleDAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ArticleDAO {

    public static Connection connection;

    public ArticleDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://mysql-momo.alwaysdata.net/momo_tpaichi";
            String username = "momo_utlisateur";
            String password = "Je123pas?";

            connection = java.sql.DriverManager.getConnection(url, username, password);

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (java.sql.SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Connection getConnection() {
        return connection;
    }

    public void ajouterArticle(Article article) {
        String sql = "INSERT INTO articles (libellé, description, prix, stock) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, article.getLibelle());
            stmt.setString(2, article.getDescription());
            stmt.setDouble(3, article.getPrix());
            stmt.setInt(4, article.getStock());
            stmt.executeUpdate();
            System.out.println("Article ajouté avec succès.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void supprimerArticle(Article article) {
        String sql = "DELETE FROM articles WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, article.getId());
            stmt.executeUpdate();
            System.out.println("Article supprimé avec succès.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void afficherArticles() {
        String sql = "SELECT * FROM articles";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String libelle = rs.getString("libellé");
                String description = rs.getString("description");
                double prix = rs.getDouble("prix");
                int stock = rs.getInt("stock");

                System.out.println("Libellé: " + libelle + ", Description: " + description + ", Prix: " + prix + ", Stock: " + stock);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Article> getArticles() {
        List<Article> articles = new ArrayList<>();
        String sql = "SELECT * FROM articles";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String libelle = rs.getString("libellé");
                String description = rs.getString("description");
                double prix = rs.getDouble("prix");
                int stock = rs.getInt("stock");

                articles.add(new Article(id, libelle, description, prix, stock));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return articles;
    }

    public void modifierArticle(Article article) {
        String sql = "UPDATE articles SET libellé = ?, description = ?, prix = ?, stock = ? WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, article.getLibelle());
            stmt.setString(2, article.getDescription());
            stmt.setDouble(3, article.getPrix());
            stmt.setInt(4, article.getStock());
            stmt.setInt(5, article.getId());
            stmt.executeUpdate();
            System.out.println("Article modifié avec succès.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Article> rechercherArticlesParNom(String texteRecherche) {
        List<Article> articles = new ArrayList<>();
        String sql = "SELECT * FROM articles WHERE libellé LIKE ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + texteRecherche + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String libelle = rs.getString("libellé");
                String description = rs.getString("description");
                double prix = rs.getDouble("prix");
                int stock = rs.getInt("stock");

                articles.add(new Article(id, libelle, description, prix, stock));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return articles;
    }
}

